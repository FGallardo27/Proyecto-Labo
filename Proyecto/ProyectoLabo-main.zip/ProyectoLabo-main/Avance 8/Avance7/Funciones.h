#pragma once
#include "Persona.h"
#include "Usuarios.h"


Usuarios login();
bool escribirUsuario();
bool verUsuarioRegistrado();