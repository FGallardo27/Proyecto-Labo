#pragma once

class Menu {

public: 
	void Ejecutar();
};

