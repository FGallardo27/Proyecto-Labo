#include <iostream>
using namespace std;
#include "Fecha.h"
#include "Persona.h"
#include "Usuarios.h"
#include "FuncionMenu.h"

using namespace std;

int main()
{
    Menu app;

    app.Ejecutar();
}
