#pragma once
class MenuUsuario{
public:
    void inicio();    

};