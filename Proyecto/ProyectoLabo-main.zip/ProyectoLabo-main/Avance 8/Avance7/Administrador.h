#pragma once
using namespace std;

class Administrador{
public:
	void cargarMenuAd();
	bool validacionDni (int DNI);
	void CargarAdmi();

};
