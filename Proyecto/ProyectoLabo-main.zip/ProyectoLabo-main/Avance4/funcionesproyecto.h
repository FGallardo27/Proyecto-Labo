#pragma once
#include <iostream>
#include <cstdio>
#include "Persona.h"
#include "usuario.h"
using namespace std;

bool escribirUsuario();
bool verUsuarioRegistrado();
