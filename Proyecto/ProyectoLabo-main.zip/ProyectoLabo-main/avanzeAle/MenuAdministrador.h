#pragma once

using namespace std;

#include "MovimientoAdministrador.h"

class MenuAdministrador
{
private:

public:
    void inicio();

};



