#pragma once
#include "MovimientoUsuario.h"
class MenuUsuario
{
private:
    
public:
    void inicio();
};


