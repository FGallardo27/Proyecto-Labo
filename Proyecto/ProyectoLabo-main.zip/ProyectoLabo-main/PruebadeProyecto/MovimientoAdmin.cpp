#include "MovimientoAdmin.h"
#include <iostream> 
using namespace std;


 MovimientoAdmin::MovimientoAdmin(int id, std::string contraAdmin){

 }

void MovimientoAdmin:: CargarProfesional(){

}
void MovimientoAdmin:: CargarTurnos(){
    int dia,mes,anio;
    int hora;
    string Especialista;
    cout<< "Fecha";
    cin>>dia;
    cin>>mes;
    cin>>anio;
    cout<< "Horario";
    cin>>hora;
    cout<< "Especialista";    
    cin>> Especialista;
}
void MovimientoAdmin:: MostrarTurnos(){

}