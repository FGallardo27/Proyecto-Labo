#include <iostream>
using namespace std;

int main(){

return 0;

}#include "Usuario.h"

Usuario::Usuario()
{
	//ctor
}
