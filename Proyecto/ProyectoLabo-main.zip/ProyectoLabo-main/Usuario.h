#include <iostream>
using namespace std;

int main(){

return 0;

}#ifndef USUARIO_H
#define USUARIO_H


class Usuario
{
	public:
		Usuario();

	protected:

	private:
};

#endif // USUARIO_H
