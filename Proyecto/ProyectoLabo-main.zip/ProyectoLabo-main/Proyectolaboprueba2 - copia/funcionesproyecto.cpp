#include <iostream>
#include "funcionesproyecto.h"
using namespace std;

/*void menuPrincipal(){
		while(true)
{
    system("cls");

    cout<<"MENU VENTAS"<<endl;
    cout<<"------------------------------"<<endl;
    cout<<"1) CARGAR DATOS"<<endl;
    cout<<"2) PUNTO A"<<endl;
    cout<<"3) PUNTO B"<<endl;
    cout<<"4) PUNTO C"<<endl;
    cout<<"5) PUNTO D"<<endl;
    cout<<"------------------------------"<<endl;
    cout<<"0) SALIR"<<endl;

    cout<<"ingrese una opcion: ";
    cin>>opc;

    system("cls");

    switch(opc)
    {
        case 1: cargarDatos(Vacu, VDia2, VDia3, VSala);
        break;
        case 2: puntoA(Vacu, 1);
        break;
        case 3: cout<<"El dia con menor cantidad de localidades vendidas fue el dia "<<puntoB(VDia2, 31)<<endl;
        break;
        case 4: puntoC( VDia3,  31);
        break;
        case 5: puntoD( VSala,  20);
        break;
        case 0: cout<<"Gracias por utilizar nuestro software"<<endl<<endl;
        return 0;
        break;
        default: cout<<"Error, opcion incorrecta"<<endl<<endl;
        break;
    }
    system("pause");

}
    return 0;
}

}
*/
