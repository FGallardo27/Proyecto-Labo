#pragma once
#include <iostream>
#include <cstdio>
#include "Persona.h"
#include "Usuario.h"
using namespace std;
//void usuarioLogeado(const Usuario& usuario);
Usuario login();
bool escribirUsuario();
bool verUsuarioRegistrado();
