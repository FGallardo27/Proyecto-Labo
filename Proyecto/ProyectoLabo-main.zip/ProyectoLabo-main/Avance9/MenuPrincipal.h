#pragma once
#include "MovimientoUsuario.h"
class MenuPrincipal
{
private:
    MovimientoUsuario _usuario;
public:
    void Ejecutar();
};

