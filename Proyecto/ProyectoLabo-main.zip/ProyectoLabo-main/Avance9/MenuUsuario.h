#pragma once

using namespace std;

#include "MovimientoUsuario.h"

class MenuUsuario
{
private:

public:
    void inicio();

};
