#include <iostream>
#include <cstring>
#include <string>

using namespace std;

#include "MenuPrincipal.h"

int main(){

    MenuPrincipal app;
    app.Ejecutar();


    return 0;

}
