#ifndef PROTOTIPOS_H_INCLUDED
#define PROTOTIPOS_H_INCLUDED

///PROTOTIPOS
bool grabarRegistro();
bool mostrarRegistros();
void cargarCadena(char *palabra, int tam);
bool bajaLogicaRegistro();

///FIN PROTOTIPOS

#endif // PROTOTIPOS_H_INCLUDED
