#pragma once
#include <cstring>
using namespace std;

void menuPrincipal();
