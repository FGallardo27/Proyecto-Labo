#pragma once
#include <iostream>
#include <cstdio>
#include "Persona.h"
#include "Usuario.h"
using namespace std;

Persona login();
bool escribirUsuario();
bool verUsuarioRegistrado();
