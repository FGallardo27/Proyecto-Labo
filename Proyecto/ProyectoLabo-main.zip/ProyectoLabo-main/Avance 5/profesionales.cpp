#pragma once;
#include <cstdlib>
#include "profesionales.h"

/*void profesionales::cargar(){
	Usuario::cargar();
	cout<<"Ingrese su titulo: ";
	cin>>titulo;
	cout<<"Ingrese su especialidad: ";
	cin>>especialidad;
}
void profesionales::mostrar(){
	Usuario::mostrar();
	cout<<"Su titulo es : "<<titulo<<endl;
	cout<<"Su especialidad es: "<<especialidad<<endl;
	cout<<"Matricula: "<<matricula<<endl;
}
*/

