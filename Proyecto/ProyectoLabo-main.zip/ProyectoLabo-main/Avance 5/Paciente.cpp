#pragma once;
#include <cstdlib>
#include "Paciente.h"

/*void Paciente::cargar(){
	Usuario::cargar();
	cout<<"Ingrese su numero de telefono: ";
	cin>>numerodeTelefono;
	cout<<"Ingrese su plan: ";
	cin>>plan;

}
void Paciente::mostrar(){
	Usuario::mostrar();
	cout<<"Su numero de telefono es: "<<numerodeTelefono<<endl;
	cout<<"Su plan de cobertura es: "<<plan<<endl;
}

*/
