#include <iostream>
#include <cstdio>
#include "funcionesproyecto.h"
#include "Persona.h"
#include "Usuario.h"
#include "Paciente.h"
#include "funcionesproyecto.h"
#include "funcionesMenu.h"

using namespace std;

int main()
{
	//Usuario nuevo;
	//FILE *n;

	menuPrincipal();
	/*escribirUsuario();
	verUsuarioRegistrado();
	*/

    return 0;
}
