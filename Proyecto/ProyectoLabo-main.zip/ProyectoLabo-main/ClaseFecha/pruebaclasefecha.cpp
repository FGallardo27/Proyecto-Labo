 #include<iostream>
 using namespace std;
 #include "PruebaclaseFecha.h"

 int main (void){

    Fecha hoy;

    hoy.Cargar();
    hoy.Mostrar();



	return 0;
 }
